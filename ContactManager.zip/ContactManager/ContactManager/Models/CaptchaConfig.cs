﻿namespace ContactManager.Models
{
    public class CaptchaConfig
    {
        public string SiteKey { get; set; }
        public string SecretKey { get; set; }
    }
}
