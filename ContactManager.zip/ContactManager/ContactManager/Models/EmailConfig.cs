﻿namespace ContactManager.Models
{
    public class EmailConfig
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
